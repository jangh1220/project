<nav id="sub_menu">
	<ul>
		<li><a href="/basic/greet/list.php">Notice</a></li>
	</ul>
</nav>