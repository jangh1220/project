<?php include "../header.php";?>
<?php include "sub_img.php";?>
<?php include "sub_menu.php";?>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<article>
	<h1>Welcome</h1>
	<figure class="ceo">
		<img src="../images/company/soldesk.jpg" width="233" height="216" alt="CEO">
		<figcaption>Storage Gateway 연동확인 </figcaption></figure>
		<p>> 온프레미스-AWS클라우드 연결<br></p>
		 <p>> 비용 및 복잡성 감소</p>
    <p>> 짧은 지연시간</p>
    <p>> 최적화된 보안 데이터 전송</p>
	<table style="float:right">
        <?php
                $urlRoot="http://169.254.169.254/latest/meta-data/";
                echo "<tr><td><b>InstanceId</b></td><td style='text-align:right'>" . file_get_contents($urlRoot . 'instance-id') . "</td></tr>";
                echo "<tr><td><b>Availability Zone</b></td><td style='text-align:right'>" . file_get_contents($urlRoot . 'placement/availability-zone') . "</td></tr>";
        ?>
	</table>
</article>


<?php include "../footer.php";?>
