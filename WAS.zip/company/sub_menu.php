<nav id="sub_menu">
	<ul>
		<li><a href="#">1조 이준영</a></li>
		<li><a href="#">1조 김진목</a></li>
		<li><a href="#">1조 배은정</a></li>
		<li><a href="#">1조 김승우</a></li>
		<li><a href="#">1조 김동혁</a></li>
	</ul>
</nav>