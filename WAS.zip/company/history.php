<? include "../header.php"?>
<? include "sub_img.php"?>
<? include "sub_menu.php"?>
<article>
	<h1> history </h1>
	<div class='y2016'>
		<h3>2016</h3>
		<dl>
			<dt>may</dt>
			<dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit</dd>
			<dd>Duis eu ipsum nisl. Duis posuere fringilla nunc quis </dd>
		</dl>
		<dl>
			<dt>apr</dt>
				<dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit</dd>
				<dd>Duis eu ipsum nisl. Duis posuere fringilla nunc quis </dd>
		</dl>
		<dl class="dot_none">
			<dt>jan</dt>
			<dd>Fusce scelerisque dictum magna eget viverra.</dd>
		</dl>
	</div>
	<div class="clear"></div>
	<div class='y2015'>
		<h3>2015</h3>
		<dl>
			<dt>may</dt>
			<dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit</dd>
			<dd>Duis eu ipsum nisl. Duis posuere fringilla nunc quis </dd>
		</dl>
		<dl>
			<dt>apr</dt>
				<dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit</dd>
				<dd>Duis eu ipsum nisl. Duis posuere fringilla nunc quis </dd>
		</dl>
		<dl class="dot_none">
			<dt>jan</dt>
			<dd>Fusce scelerisque dictum magna eget viverra.</dd>
		</dl>
	</div>
</article>
<? include "../footer.php"?>