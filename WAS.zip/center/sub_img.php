<div id="sub_img_center"></div>
<div class="clear"></div>